<?php

$lang['api_key']="API KLÍČ";
$lang['offer_cz']="Nabízet pobočky v ČR";
$lang['offer_sk']="Nabízet pobočky v SR";
$lang['price_cz']="Cena zásilky do ČR";
$lang['price_sk']="Cena zásilky do SR";
$lang['info_cz']="Info do ČR";
$lang['info_sk']="Info do SR";
$lang['packet_price']="Cena za zásilku";
$lang['delivery_info']="Informace";
$lang['cash_on_del_fee']="Příplatek za dobírku";
$lang['select_cash_on_del_payments']="Vyberte platby, které jsou na dobírku";
$lang['select_cash_on_del_payments_tip']="Vyberte platby, které jsou na dobírku";
$lang['eshop_domain']="Doména eshopu";
$lang['eshop_domain_tip']="Používáte-li jeden účet Zásilkovny pro více e-shopů, zadejte zde doménu tohoto, aby bylo možné řádně informovat zákazníky o původu zásilky, která je jim dopravována.";
$lang['show_logo']='Zobrazovat logo Zasilkovna.cz';
$lang['label_cz']='Nazev dopravy pro ČR';
$lang['label_sk']='Nazev dopravy pro SR';



