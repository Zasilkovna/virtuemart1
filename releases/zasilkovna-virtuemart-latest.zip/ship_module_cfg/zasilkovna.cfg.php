<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

$config['api_key']='9811daa7a7186551';
$config['eshop_domain']='testshop.local';
$config['currency']='CZK';
$config['cz']['_branches']='_branches_true';
$config['cz']['_branch_price']='14.00';
$config['cz']['_cash_on_del_fee']='';
$config['cz']['_info']='Info pro ČR';
$config['cz']['_show_logo']='_show_logo_true';
$config['cz']['_shipper_name']='Zasilkovna.cz';
$config['sk']['_branches']='_branches_true';
$config['sk']['_branch_price']='8.00';
$config['sk']['_cash_on_del_fee']='';
$config['sk']['_info']='Info pro SR';
$config['sk']['_show_logo']='_show_logo_true';
$config['sk']['_shipper_name']='Zasielkovna.cz';
$config['cod2']='true';
$config['cod20']='true';
