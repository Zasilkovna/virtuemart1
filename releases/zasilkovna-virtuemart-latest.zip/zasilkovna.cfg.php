<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

$config['api_key']='';
$config['eshop_domain']='';
$config['currency']='EUR';
$config['fix_prices']='fix_prices_true';
$config['_tax_rate']='0';
$config['cz']['_branches']='_branches_true';
$config['cz']['_branch_price']='0.55';
$config['cz']['_cash_on_del_fee']='';
$config['cz']['_info']='Info pro ČR';
$config['cz']['_show_logo']='_show_logo_true';
$config['cz']['_shipper_name']='Zasilkovna.cz';
$config['cz']['_fix_price_CZK']='35';
$config['cz']['_fix_price_EUR']='1';
$config['cz']['_fix_price_USD']='1.5';
$config['cz']['_priority']='1';
$config['sk']['_branches']='_branches_true';
$config['sk']['_branch_price']='0.31';
$config['sk']['_cash_on_del_fee']='';
$config['sk']['_info']='Info pro SR';
$config['sk']['_show_logo']='_show_logo_true';
$config['sk']['_shipper_name']='Zasielkovna.cz';
$config['sk']['_fix_price_CZK']='35';
$config['sk']['_fix_price_EUR']='1';
$config['sk']['_fix_price_USD']='1.5';
$config['sk']['_priority']='0';
